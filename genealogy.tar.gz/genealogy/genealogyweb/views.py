from django.shortcuts import render


def login(request):
    return render(request,'login.html',locals())

def fimalyintro(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        id_number = request.POST.get('id_number')
        print(name)
    return render(request, 'fimalyintro.html', locals())


def fimalymain(request):

    wushizu = {'name': '元良', 'number': 'number'}
    liushizu = {'name': '長門 周南 祖宗系', 'number': 'number', 'name': '貳門 召南 祖宗系', 'number': 'number','name': '叁門 汝城 祖宗系', 'number': 'number'}

    return  render(request,'fimalymain.html',locals())