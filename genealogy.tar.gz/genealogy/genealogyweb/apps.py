from django.apps import AppConfig


class GenealogywebConfig(AppConfig):
    name = 'genealogyweb'
