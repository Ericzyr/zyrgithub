from django.shortcuts import render

import json
import collections

def login(request):
    return render(request,'login.html',locals())

def fimalyintro(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        id_number = request.POST.get('id_number')
        print(name)
    return render(request, 'fimalyintro.html', locals())


def fimalymain(request):
    if request.method == 'POST':
        pass

    def family(argv):
        sum = 0
        for i in argv.values():
            sum = sum + i
        return sum
# ===========================================================
    zhaoxiangzz={}
    zhaoxiangzz=zhaoxiangzz失諱長=collections.OrderedDict()
    zhaoxiangzz失諱長['乏嗣'] = 1

    xifeng={}
    xifeng =希鳳次= collections.OrderedDict()
    希鳳次['翠冬'] = 2

    zhaoxiangzs={}
    zhaoxiangzs=zhaoxiangzs失諱三=collections.OrderedDict()
    zhaoxiangzs失諱三['乏嗣'] = 1

    congwu={}
    congwu=從武=collections.OrderedDict()
    從武['望峰長'] = 2
    從武['嶺峰次'] = 2

    xisheng={}
    xisheng=希聖長=collections.OrderedDict()
    希聖長['翠峰']=2

    congyan={}
    congyan=從顏次=collections.OrderedDict()
    從顏次['年峰']=2
    從顏次['喜峰']=2

    congming={}
    congming=從敏三=collections.OrderedDict()
    從敏三['春峰長']=2
    從敏三['秋峰次']=2
    從敏三['洪峰']=2

    jhzsz={}
    jhzsz=失諱長=collections.OrderedDict()
    失諱長['翠朋']=2
    失諱長['翠盘']=2
    失諱長['翠昂']=2



    jhssz={}
    jhssz=失諱長=collections.OrderedDict()
    失諱長['西峰長']=2
    失諱長['東峰次']=2
    失諱長['泰峰三']=2


    jhssc={}
    jhssc=錫智次=collections.OrderedDict()
    錫智次['秀峰長'] = 2
    錫智次['山峰次'] = 2
    錫智次['昆峰三'] = 2
    錫智次['峙峰四'] = 2
# =========================================================================
















# ============================================================================
# 长门 =================九世祖 從===============================

    zhaoxiang={}
    zhaoxiang=朝相=collections.OrderedDict()
    朝相['失諱-長']=family(zhaoxiangzz失諱長)
    朝相['希鳳-次']=family(xifeng)
    朝相['失諱-三']=family(zhaoxiangzs失諱三)

    wu={}
    wu=无=collections.OrderedDict()
    无['']=1

    wu = {}
    wu = 无 = collections.OrderedDict()
    无[''] = 1

    hongbaosan={}
    hongbaosan=洪賓三=collections.OrderedDict()
    洪賓三['從武']=family(從武)


    # ===========================================

    zhaogan={}
    zhaogan=朝斡嗣子=collections.OrderedDict()
    朝斡嗣子['希聖-長']=family(希聖長)
    朝斡嗣子['從顏-次']=family(從顏次)
    朝斡嗣子['從敏-三']=family(從敏三)

    jhzs={}
    jhzs=基恒长孙=collections.OrderedDict()
    基恒长孙['失諱-長']=family(失諱長)
    基恒长孙['失諱-次']=1

    jhss={}
    jhss=基恒三孙 = collections.OrderedDict()
    基恒三孙['失諱-長']= family(失諱長)
    基恒三孙['錫智-次']= family(錫智次)



# =====================================================

    rmznzrz={}
    rmznzrz=rmznzrz失諱長=collections.OrderedDict()
    rmznzrz失諱長['希仁-長']= 1
    rmznzrz失諱長['失諱-次']= 2
    rmznzrz失諱長['希德-三']= 2

    rmznzrc={}
    rmznzrc=rmznzrc失諱次=collections.OrderedDict()
    rmznzrc失諱次['失諱'] = 1



    zhaoxuan={}
    zhaoxuan=朝選=collections.OrderedDict()
    朝選['從順-長']= 1
    朝選['從讓-次']= 1
    朝選['失諱-三']= 1


    zhaozheng = {}
    zhaozheng = 朝臻長=collections.OrderedDict()
    朝臻長['失諱']= 2

    zhaohai = {}
    zhaohai = 朝海次 = collections.OrderedDict()
    朝海次['從武'] = 1

    zhaoyuan = {}
    zhaoyuan = 朝元三 = collections.OrderedDict()
    朝元三['從君-長'] = 2
    朝元三['從舉-次'] = 2
    朝元三['從周-三'] = 2

    dengsanccs = {}
    dengsanccs = dengsanccs失諱=collections.OrderedDict()
    dengsanccs失諱['從一-長'] = 2
    dengsanccs失諱['從萬-次'] = 2

    zhaofan={}
    zhaofan=朝范=collections.OrderedDict()
    朝范['從謙-長'] = 2
    朝范['從政-次'] = 2


    zhaoxi = {}
    zhaoxi = 朝璽 =collections.OrderedDict()
    朝璽['從云'] = 1

    zhaoju={}
    zhaoju=朝舉=collections.OrderedDict()
    朝舉['從禮-長'] = 2
    朝舉['從義-次'] = 2

    zhaozong={}
    zhaozong=朝宗=collections.OrderedDict()
    朝宗['從仁-長'] = 2
    朝宗['從文-次'] = 2
# =======================================================

    smrczzz={}
    smrczzz=smrczzz失諱長=collections.OrderedDict()
    smrczzz失諱長['希順-長'] = 2
    smrczzz失諱長['希五-次'] = 2

    smrczcc = {}
    smrczcc = smrczcc失諱次=collections.OrderedDict()
    smrczcc失諱次['希堯-長'] = 2
    smrczcc失諱次['希舉-次'] = 2

    smrczsans={}
    smrczsans=smrczsans失諱=collections.OrderedDict()
    smrczsans失諱['失諱'] = 2


    zhaoyan={}
    zhaoyan=朝彥=collections.OrderedDict()
    朝彥['從善'] = 2

    zhaogui={}
    zhaogui=朝貴長=collections.OrderedDict()
    朝貴長['從友']= 1

    zhaoxian={}
    zhaoxian=朝獻次=collections.OrderedDict()
    朝獻次['從善-長'] = 2
    朝獻次['從修-次'] = 2
    朝獻次['從德-三'] = 2

    zhaojun={}
    zhaojun=朝君長=collections.OrderedDict()
    朝君長['從儉-長'] = 2
    朝君長['從緒-出嗣'] = 2
    朝君長['從法-三'] = 2

    zhaoqing={}
    zhaoqing=朝清次=collections.OrderedDict()
    朝清次['從緒-嗣'] = 1

    zhaowu={}
    zhaowu=朝五=collections.OrderedDict()
    朝五['從廉-長'] = 2
    朝五['從榮-次'] = 2
# ====================================================================
    zhaocheng={}
    zhaocheng=朝臣=collections.OrderedDict()
    朝臣['從周-長']=2
    朝臣['從斌-次']=2
    朝臣['從三-三']=2
    朝臣['從仕-四']=2
    朝臣['從伍-五']=2

# ============================================================================
# 长门 =================八世祖 朝===============================
    bszjz ={}
    bszjz=bszjz失諱長=collections.OrderedDict()
    bszjz失諱長['朝相']=family(朝相)

    bszjc={}
    bszjc=bszjc失諱次=collections.OrderedDict()
    bszjc失諱次['失諱-長'] = family(无)
    bszjc失諱次['失諱-次'] = family(无)
    bszjc失諱次['洪賓-三'] = family(洪賓三)


    jimao={}
    jimao=基茂=collections.OrderedDict()
    基茂['朝斡-嗣']=family(朝斡嗣子)



    jiheng={}
    jiheng=基恒=collections.OrderedDict()
    基恒['失諱-長']= family(基恒长孙)
    基恒['朝斡-出嗣']= 1
    基恒['失諱-三']=family(基恒三孙)

# ============================================================================
# 二门 =================八世祖 朝===============================
    rmznzr={}
    rmznzr=rmznzr失諱長=collections.OrderedDict()
    rmznzr失諱長['失諱-長']= family(rmznzrz失諱長)
    rmznzr失諱長['失諱-次']= family(rmznzrc失諱次)

    rmznzc={}
    rmznzc=rmznzc失諱次=collections.OrderedDict()
    rmznzc失諱次['朝選-']=family(朝選)

    zmznrz={}
    zmznrz=zmznrz失諱=collections.OrderedDict()
    zmznrz失諱['乏嗣'] = 1


    jishan={}
    jishan=基善長=collections.OrderedDict()
    基善長['朝臻-長'] = family(朝臻長)
    基善長['朝海-次'] = family(朝海次)
    基善長['朝元-三'] = family(朝元三)

    dengsancc={}
    dengsancc=dengsancc失諱次=collections.OrderedDict()
    dengsancc失諱次['失諱']=family(dengsanccs)

    jikang={}
    jikang =基康=collections.OrderedDict()
    基康['朝范']=family(朝范)


    jiyi={}
    jiyi=基凝長=collections.OrderedDict()
    基凝長['朝璽']=family(朝璽)

    jiduan={}
    jiduan=基端次=collections.OrderedDict()
    基端次['朝舉']=family(朝舉)


    jitian={}
    jitian=基田三=collections.OrderedDict()
    基田三['朝宗'] = family(朝宗)


# =================================================
    smrczz={}
    smrczz=smrczz失諱長=collections.OrderedDict()
    smrczz失諱長['失諱'] = family(smrczzz失諱長)

    smrczc= {}
    smrczc = smrczc失諱次 = collections.OrderedDict()
    smrczc失諱次['失諱'] = family(smrczcc失諱次)

    smrczsan = {}
    smrczsan = smrczsan失諱三 = collections.OrderedDict()
    smrczsan失諱三 ['失諱'] = family(smrczsans失諱)

    smrczsi = {}
    smrczsi = smrczsi失諱四 = collections.OrderedDict()
    smrczsi失諱四['朝彥'] = family(朝彥)


    jitai={}
    jitai=基泰=collections.OrderedDict()
    基泰['朝貴-長'] = family(朝貴長)
    基泰['朝獻-次'] = family(朝獻次)

    jilong={}
    jilong=基隆長=collections.OrderedDict()
    基隆長['朝君-長']= family(朝君長)
    基隆長['朝清-次']= family(朝清次)

    jiyao={}
    jiyao=基耀次=collections.OrderedDict()
    基耀次['朝五-']=family(朝五)

    # ===================================================

    jiliang={}
    jiliang=基亮=collections.OrderedDict()
    基亮['朝臣'] =family(朝臣)



#============================================================================
    # 长门 =================八世祖 基===============================
    zmznz ={}
    zmznz=zmznz失諱長=collections.OrderedDict()
    zmznz失諱長['失諱-長'] = family(bszjz失諱長)
    zmznz失諱長['失諱-次']= family(bszjc失諱次)

    zhuoci ={}
    zhuoci = 灼次 =collections.OrderedDict()
    灼次['基茂'] = family(基茂)


    zmznthree ={}
    zmznthree = 失諱三=collections.OrderedDict()
    失諱三['基恒']=family(基恒)



    # 二门 =================八世祖 基==============================
    rmznz = {}
    rmznz = rmznz失諱長 = collections.OrderedDict()
    rmznz失諱長['失諱-長'] = family(rmznzr失諱長)
    rmznz失諱長['失諱-次'] = family(rmznzc失諱次)

    rmznr = {}
    rmznr = rmznr失諱次 = collections.OrderedDict()
    rmznr失諱次['失諱-'] = family(zmznrz失諱)


    dengsan = {}
    dengsan= 燈三=collections.OrderedDict()
    燈三['基善-長'] = family(基善長)
    燈三['失諱-次'] = family(dengsancc失諱次)

    xuansi = {}
    xuansi= 煊四=collections.OrderedDict()
    煊四['基康'] = family(基康)

    qinwu = {}
    qinwu= 勤五=collections.OrderedDict()
    勤五['基凝-長'] = family(基凝長)
    勤五['基端-次'] = family(基端次)
    勤五['基田-三'] = family(基田三)

    #三门====================八世祖 基===================

    smrcz ={}
    smrcz=smrcz失諱長=collections.OrderedDict()
    smrcz失諱長['失諱-長'] = family(smrczz失諱長)
    smrcz失諱長['失諱-次'] = family(smrczc失諱次)
    smrcz失諱長['失諱-三'] = family(smrczsan失諱三)
    smrcz失諱長['失諱-四'] = family(smrczsi失諱四)

    canci={}
    canci=燦次=collections.OrderedDict()
    燦次['基泰']=family(基泰)

    yusan = {}
    yusan = 煜三 = collections.OrderedDict()
    煜三['基隆-長'] = family(基隆長)
    煜三['基耀-次'] = family(基耀次)

    # 旁支===================八世祖 基========================

    zhu={}
    zhu=渚=collections.OrderedDict()
    渚['基亮-'] = family(基亮)



# ================================================================
    # ===========================七世祖===========================
    zmzn = {}
    zmzn = 長門周南祖宗系= collections.OrderedDict()
    長門周南祖宗系['失諱(長)'] = family(zmznz失諱長)
    長門周南祖宗系['灼(次)'] = family(灼次)
    長門周南祖宗系['失諱(三)'] = family(失諱三)


    rmzn = {}
    rmzn = 貳門召南祖宗系 = collections.OrderedDict()
    貳門召南祖宗系['失諱-長'] = family(rmznz失諱長)
    貳門召南祖宗系['失諱-次'] = family(rmznr失諱次)
    貳門召南祖宗系['燈-三'] = family(燈三)
    貳門召南祖宗系['煊-四'] = family(煊四)
    貳門召南祖宗系['勤-五'] = family(勤五)


    smrc = {}
    smrc = 叁門汝城祖宗系 = collections.OrderedDict()
    叁門汝城祖宗系['失諱-長'] = family(smrcz失諱長)
    叁門汝城祖宗系['燦-次'] = family(燦次)
    叁門汝城祖宗系['煜-三'] = family(煜三)

    pztnp = {}
    pztnp = 旁支太南祖宗系 = collections.OrderedDict()
    旁支太南祖宗系['渚'] = family(渚)

# ================================================================
    # ========================六世祖===========================
    six = {}
    six = 六世祖 = collections.OrderedDict()
    六世祖['長門周南祖宗系'] = family(長門周南祖宗系)
    六世祖['貳門召南祖宗系'] = family(貳門召南祖宗系)
    六世祖['叁門汝城祖宗系'] = family(叁門汝城祖宗系)

    pztn = {}
    pztn = 六世祖旁支太南祖宗系 = collections.OrderedDict()
    六世祖旁支太南祖宗系['旁支太南祖宗系'] = family(旁支太南祖宗系)



# ================================================================
    # =======================五世祖============================

    five = 五世祖 = {'元良祖宗系': family(六世祖)}




    return render(request,'fimalymain.html',locals())